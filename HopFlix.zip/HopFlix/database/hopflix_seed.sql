USE hopflix;
SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE episodes; TRUNCATE TABLE seasons; TRUNCATE TABLE content_genres;
TRUNCATE TABLE favourites; TRUNCATE TABLE watch_history;
TRUNCATE TABLE content; TRUNCATE TABLE genres; TRUNCATE TABLE users;
SET FOREIGN_KEY_CHECKS = 1;

-- Test Users
INSERT INTO users (id,username,email,password,role) VALUES
(1,'admin', 'admin@hopflix.com', 'admin123', 'admin'),
(2,'testuser','test@hopflix.com', 'password123', 'user');

-- Genres
INSERT INTO genres (id,name) VALUES
(1,'Action'),(2,'Adult'),(3,'Adventure'),(4,'Animation'),
(5,'Comedy'),(6,'Crime'),(7,'Drama'),(8,'Family'),
(9,'Fantasy'),(10,'History'),(11,'Horror'),(12,'Medical'),
(13,'Musical'),(14,'Mystery'),(15,'Romance'),(16,'Sci-Fi'),
(17,'Thriller'),(18,'War');

-- TV Series
INSERT INTO content (id,title,type,year,rating,description,cover_url,banner_url,trailer_url,featured,views) VALUES
(1,'Amphibia','series',2019,8.1,
  'A self-centered teenager is transported to Amphibia, a world of frog people.',
  '/HopFlix/images/covers/amphibia.jpg',
  '/HopFlix/images/carousel-banners/amphibia.jpg',
  'https://www.youtube.com/embed/dfYAb84mnZg',0,1420),

(2,'Gravity Falls','series',2012,8.9,
  'Twin siblings spend summer at their great-uncle tourist trap in mysterious Gravity Falls.',
  '/HopFlix/images/covers/gravity-falls.jpg',
  '/HopFlix/images/carousel-banners/gravity-falls.jpg',
  'https://www.youtube.com/embed/2-UE94bYEqY',1,3800),

(3,'The Neighbourhood','series',2018,6.8,
  'A friendly Midwest family moves to a not-so-friendly Los Angeles neighbourhood.',
  '/HopFlix/images/covers/the-neighbourhood.jpg',
  '/HopFlix/images/carousel-banners/the-neighbourhood.jpg',
  'https://www.youtube.com/embed/8NwMUoYVm6A',0,970),

(4,'Grey''s Anatomy','series',2005,7.6,
  'Drama centered on surgical interns and supervisors at a Seattle hospital.',
  '/HopFlix/images/covers/greys-anatomy.jpg',
  '/HopFlix/images/carousel-banners/greys-anatomy.jpg',
  'https://www.youtube.com/embed/4Yak-NSlR2c',1,5100),

(5,'Helluva Boss','series',2020,8.4,
  'An imp starts a business specializing in assassinations for souls in Hell.',
  '/HopFlix/images/covers/helluva-boss.jpg',
  '/HopFlix/images/carousel-banners/helluva-boss.jpg',
  'https://www.youtube.com/embed/el_PChGfJN8',1,4200),

(6,'Hazbin Hotel','series',2024,8.0,
  'Charlie, princess of Hell, opens a hotel to rehabilitate demons.',
  '/HopFlix/images/covers/hazbin-hotel.jpg',
  '/HopFlix/images/carousel-banners/hazbin-hotel.jpg',
  'https://www.youtube.com/embed/iN0rFuCCA-Y',1,4600),

(7,'The Amazing Digital Circus','series',2023,8.6,
  'Humans trapped in a digital circus struggle to maintain their sanity.',
  '/HopFlix/images/covers/amazing-digital-circus.jpg',
  '/HopFlix/images/carousel-banners/amazing-digital-circus.jpg',
  'https://www.youtube.com/embed/iuaRQ5NQFq8',1,5300),

(8,'Murder Drones','series',2023,8.3,
  'Murder Drones exterminate Worker Drones on an abandoned planet.',
  '/HopFlix/images/covers/murder-drones.jpg',
  '/HopFlix/images/carousel-banners/murder-drones.jpg',
  'https://www.youtube.com/embed/xIebUcOxkMg',0,3100),

(9,'Avatar: The Last Airbender','series',2005,9.3,
  'A young Avatar must master all four elements to bring peace.',
  '/HopFlix/images/covers/avatar-tla.jpg',
  '/HopFlix/images/carousel-banners/avatar-tla.jpg',
  'https://www.youtube.com/embed/ooVvH2IYz0w',1,7800),

(10,'Ghosts','series',2021,7.8,
  'A couple inherits a mansion haunted by ghosts from different eras.',
  '/HopFlix/images/covers/ghosts.jpg',
  '/HopFlix/images/carousel-banners/ghosts.jpg',
  'https://www.youtube.com/embed/gRnfBWqMWcE',0,1600),

(11,'The Rookie','series',2018,8.0,
  'Middle-aged man becomes the oldest rookie at the LAPD.',
  '/HopFlix/images/covers/the-rookie.jpg',
  '/HopFlix/images/carousel-banners/the-rookie.jpg',
  'https://www.youtube.com/embed/8BPlx6eK1vc',0,2300),

(12,'Arcane','series',2021,9.0,
  'Origins of two iconic League of Legends champions in Piltover and Zaun.',
  '/HopFlix/images/covers/arcane.jpg',
  '/HopFlix/images/carousel-banners/arcane.jpg',
  'https://www.youtube.com/embed/4Ps6nV4wiCE',1,8200),

(13,'The Last of Us','series',2023,8.8,
  'Joel smuggles immune Ellie across a post-apocalyptic United States.',
  '/HopFlix/images/covers/the-last-of-us.jpg',
  '/HopFlix/images/carousel-banners/the-last-of-us.jpg',
  'https://www.youtube.com/embed/uLtkt8BonwM',1,9100),

(14,'The Walking Dead','series',2010,8.1,
  'Rick Grimes leads survivors in a zombie apocalypse.',
  '/HopFlix/images/covers/the-walking-dead.jpg',
  '/HopFlix/images/carousel-banners/the-walking-dead.jpg',
  'https://www.youtube.com/embed/sfAc2U20uyg',0,4300),

(15,'Alice in Borderland','series',2020,7.7,
  'A gamer competes in deadly games in a dystopian Tokyo.',
  '/HopFlix/images/covers/alice-in-borderland.jpg',
  '/HopFlix/images/carousel-banners/alice-in-borderland.jpg',
  'https://www.youtube.com/embed/49_44FFKZ1M',1,6400),

(16,'Breaking Bad','series',2008,9.5,
  'A chemistry teacher turns to cooking meth after a cancer diagnosis.',
  '/HopFlix/images/covers/breaking-bad.jpg',
  '/HopFlix/images/carousel-banners/breaking-bad.jpg',
  'https://www.youtube.com/embed/HhesaQXLuRY',1,12000),

(17,'Stranger Things','series',2016,8.7,
  'Kids uncover supernatural mysteries in small-town Indiana.',
  '/HopFlix/images/covers/stranger-things.jpg',
  '/HopFlix/images/carousel-banners/stranger-things.jpg',
  'https://www.youtube.com/embed/b9EkMc79ZSU',1,11000),

(18,'Wednesday','series',2022,8.1,
  'Wednesday Addams solves mysteries at Nevermore Academy.',
  '/HopFlix/images/covers/wednesday.jpg',
  '/HopFlix/images/carousel-banners/wednesday.jpg',
  'https://www.youtube.com/embed/Di310WS8zLk',0,8500),

(19,'One Piece','series',1999,8.9,
  'Monkey D. Luffy sails the seas to become King of the Pirates.',
  '/HopFlix/images/covers/one-piece.jpg',
  '/HopFlix/images/carousel-banners/one-piece.jpg',
  'https://www.youtube.com/embed/MCb13lbVGE0',0,7200),

(20,'Demon Slayer','series',2019,8.7,
  'Tanjiro becomes a demon slayer after his family is slaughtered.',
  '/HopFlix/images/covers/demon-slayer.jpg',
  '/HopFlix/images/carousel-banners/demon-slayer.jpg',
  'https://www.youtube.com/embed/VQGCKyvzIM4',1,9300),

(21,'Jujutsu Kaisen','series',2020,8.6,
  'A student joins a secret organization of sorcerers to kill Curses.',
  '/HopFlix/images/covers/jujutsu-kaisen.jpg',
  '/HopFlix/images/carousel-banners/jujutsu-kaisen.jpg',
  'https://www.youtube.com/embed/4A_X-Dvl0ws',0,8800),

(22,'The Bear','series',2022,8.7,
  'A fine dining chef returns to run his family sandwich shop.',
  '/HopFlix/images/covers/the-bear.jpg',
  '/HopFlix/images/carousel-banners/the-bear.jpg',
  'https://www.youtube.com/embed/QywHyWBoHHY',0,5600),

(23,'Succession','series',2018,8.9,
  'The Roy family fights over control of their media empire.',
  '/HopFlix/images/covers/succession.jpg',
  '/HopFlix/images/carousel-banners/succession.jpg',
  'https://www.youtube.com/embed/OrmHXXhJpYc',0,6100);

INSERT INTO content (id,title,type,year,rating,description,cover_url,banner_url,trailer_url,featured,views,duration) VALUES
(101,'The Goat','movie',2023,6.5,
  'A lighthearted comedy about unexpected encounters.',
  '/HopFlix/images/covers/the-goat.jpg',
  '/HopFlix/images/carousel-banners/the-goat.jpg',
  'https://www.youtube.com/embed/5r-7eWDBc40',0,890,'1h 45m'),

(102,'Inside Out','movie',2015,8.2,
  'Riley''s emotions conflict as she navigates moving to a new city.',
  '/HopFlix/images/covers/inside-out.jpg',
  '/HopFlix/images/carousel-banners/inside-out.jpg',
  'https://www.youtube.com/embed/yRUAzGQ3nSY',1,6700,'1h 35m'),

(103,'Inside Out 2','movie',2024,7.8,
  'Riley enters adolescence and Anxiety joins her existing emotions.',
  '/HopFlix/images/covers/inside-out-2.jpg',
  '/HopFlix/images/carousel-banners/inside-out-2.jpg',
  'https://www.youtube.com/embed/LEjhY15eCx0',1,7200,'1h 40m'),

(104,'Hoppers','movie',2024,7.0,
  'An adventure about leaping through unexpected places.',
  '/HopFlix/images/covers/hoppers.jpg',
  '/HopFlix/images/carousel-banners/hoppers.jpg',
  'https://www.youtube.com/embed/PypDSyIRRSs',0,1100,'1h 52m'),

(105,'Hacksaw Ridge','movie',2016,8.2,
  'WWII conscientious objector Desmond Doss earns the Medal of Honor.',
  '/HopFlix/images/covers/hacksaw-ridge.jpg',
  '/HopFlix/images/carousel-banners/hacksaw-ridge.jpg',
  'https://www.youtube.com/embed/s2-1hz1juBI',1,4100,'2h 19m'),

(106,'The Black Phone','movie',2021,7.4,
  'An abducted boy uses a disconnected phone to talk with past victims.',
  '/HopFlix/images/covers/the-black-phone.jpg',
  '/HopFlix/images/carousel-banners/the-black-phone.jpg',
  'https://www.youtube.com/embed/3eGP6im8AZA',0,2800,'1h 43m'),

(107,'Avatar','movie',2009,7.9,
  'A marine on Pandora becomes torn between orders and protecting his new home.',
  '/HopFlix/images/covers/avatar-1.jpg',
  '/HopFlix/images/carousel-banners/avatar-1.jpg',
  'https://www.youtube.com/embed/5PSNL1qE6VY',1,8900,'2h 42m'),

(108,'Avatar: The Way of Water','movie',2022,7.6,
  'Jake Sully and family explore the ocean regions of Pandora.',
  '/HopFlix/images/covers/avatar-2.jpg',
  '/HopFlix/images/carousel-banners/avatar-2.jpg',
  'https://www.youtube.com/embed/d9MyW72ELq0',0,5600,'3h 12m'),

(109,'Avatar 3','movie',2025,7.8,
  'The next chapter in the epic Avatar saga continues.',
  '/HopFlix/images/covers/avatar-3.jpg',
  '/HopFlix/images/carousel-banners/avatar-3.jpg',
  'https://www.youtube.com/embed/nb_fFj_0rq8',1,6900,'2h 58m'),

(110,'Blue Beetle','movie',2023,6.8,
  'Jaime Reyes bonds with an alien relic that gives him incredible armor.',
  '/HopFlix/images/covers/blue-beetle.jpg',
  '/HopFlix/images/carousel-banners/blue-beetle.jpg',
  'https://www.youtube.com/embed/vS3_72Gb-bI',0,2100,'2h 7m'),

(111,'Zootopia','movie',2016,8.0,
  'A bunny cop and con artist fox uncover a conspiracy in animal city.',
  '/HopFlix/images/covers/zootopia.jpg',
  '/HopFlix/images/carousel-banners/zootopia.jpg',
  'https://www.youtube.com/embed/jWM0ct-OLsM',1,5400,'1h 48m'),

(112,'Spider-Man: Across the Spider-Verse','movie',2023,8.7,
  'Miles Morales catapults across the Multiverse to protect its existence.',
  '/HopFlix/images/covers/spiderman-across.jpg',
  '/HopFlix/images/carousel-banners/spiderman-across.jpg',
  'https://www.youtube.com/embed/cqGjhVJWtEg',1,9500,'2h 20m'),

(113,'Spider-Man: Into the Spider-Verse','movie',2018,8.4,
  'Teen Miles Morales becomes Spider-Man and meets multiverse counterparts.',
  '/HopFlix/images/covers/spiderman-into.jpg',
  '/HopFlix/images/carousel-banners/spiderman-into.jpg',
  'https://www.youtube.com/embed/tg52up16eq0',1,8700,'1h 57m'),

(114,'Interstellar','movie',2014,8.7,
  'Explorers travel through a wormhole to ensure humanity''s survival.',
  '/HopFlix/images/covers/interstellar.jpg',
  '/HopFlix/images/carousel-banners/interstellar.jpg',
  'https://www.youtube.com/embed/zSWdZVtXT7E',1,9200,'2h 49m'),

(115,'Inception','movie',2010,8.8,
  'A thief plants an idea into a target''s mind through dream-sharing.',
  '/HopFlix/images/covers/inception.jpg',
  '/HopFlix/images/carousel-banners/inception.jpg',
  'https://www.youtube.com/embed/YoHD9XEInc0',0,8600,'2h 28m'),

(116,'The Dark Knight','movie',2008,9.0,
  'Batman faces the Joker''s reign of chaos in Gotham City.',
  '/HopFlix/images/covers/the-dark-knight.jpg',
  '/HopFlix/images/carousel-banners/the-dark-knight.jpg',
  'https://www.youtube.com/embed/EXeTwQWrcwY',1,10500,'2h 32m'),

(117,'Dune','movie',2021,8.0,
  'Paul Atreides leads Fremen in revolt on the desert planet Arrakis.',
  '/HopFlix/images/covers/dune.jpg',
  '/HopFlix/images/carousel-banners/dune.jpg',
  'https://www.youtube.com/embed/n9xhJrPXop4',0,7400,'2h 35m'),

(118,'Dune: Part Two','movie',2024,8.5,
  'Paul Atreides wages war against conspirators who destroyed his family.',
  '/HopFlix/images/covers/dune-part-2.jpg',
  '/HopFlix/images/carousel-banners/dune-part-2.jpg',
  'https://www.youtube.com/embed/Way9Dexny3w',1,8100,'2h 46m'),

(119,'Oppenheimer','movie',2023,8.3,
  'The story of J. Robert Oppenheimer and the atomic bomb.',
  '/HopFlix/images/covers/oppenheimer.jpg',
  '/HopFlix/images/carousel-banners/oppenheimer.jpg',
  'https://www.youtube.com/embed/uYPbbksJxIg',0,7800,'3h'),

(120,'Barbie','movie',2023,6.9,
  'Barbie and Ken visit the real world and discover joys and perils of humans.',
  '/HopFlix/images/covers/barbie.jpg',
  '/HopFlix/images/carousel-banners/barbie.jpg',
  'https://www.youtube.com/embed/pBk4NYhWNMM',0,6500,'1h 54m'),

(121,'Past Lives','movie',2023,7.9,
  'Two childhood sweethearts are reunited decades later.',
  '/HopFlix/images/covers/past-lives.jpg',
  '/HopFlix/images/carousel-banners/past-lives.jpg',
  'https://www.youtube.com/embed/kA3SXkCUxMc',0,3200,'1h 46m'),

(122,'Poor Things','movie',2023,8.0,
  'A young woman brought back to life embarks on a journey of self-discovery.',
  '/HopFlix/images/covers/poor-things.jpg',
  '/HopFlix/images/carousel-banners/poor-things.jpg',
  'https://www.youtube.com/embed/RlbR5N6veqw',0,4100,'2h 21m');

-- Series
INSERT INTO content_genres VALUES (1,4),(1,3),(1,5),(1,8);
INSERT INTO content_genres VALUES (2,4),(2,14),(2,5),(2,8);
INSERT INTO content_genres VALUES (3,5),(3,7);
INSERT INTO content_genres VALUES (4,7),(4,15),(4,12);
INSERT INTO content_genres VALUES (5,4),(5,5),(5,11),(5,2);
INSERT INTO content_genres VALUES (6,4),(6,5),(6,13),(6,2);
INSERT INTO content_genres VALUES (7,4),(7,5),(7,11),(7,9);
INSERT INTO content_genres VALUES (8,4),(8,16),(8,11),(8,1);
INSERT INTO content_genres VALUES (9,4),(9,3),(9,9),(9,1);
INSERT INTO content_genres VALUES (10,5),(10,9);
INSERT INTO content_genres VALUES (11,7),(11,6),(11,1);
INSERT INTO content_genres VALUES (12,4),(12,1),(12,9),(12,7);
INSERT INTO content_genres VALUES (13,7),(13,11),(13,1),(13,16);
INSERT INTO content_genres VALUES (14,7),(14,11),(14,1);
INSERT INTO content_genres VALUES (15,1),(15,16),(15,17),(15,7);
INSERT INTO content_genres VALUES (16,7),(16,6),(16,17);
INSERT INTO content_genres VALUES (17,16),(17,11),(17,7),(17,14);
INSERT INTO content_genres VALUES (18,5),(18,11),(18,14),(18,9);
INSERT INTO content_genres VALUES (19,4),(19,3),(19,1),(19,5);
INSERT INTO content_genres VALUES (20,4),(20,1),(20,9),(20,7);
INSERT INTO content_genres VALUES (21,4),(21,1),(21,11),(21,9);
INSERT INTO content_genres VALUES (22,7),(22,5);
INSERT INTO content_genres VALUES (23,7),(23,5);

-- Movies
INSERT INTO content_genres VALUES (101,5),(101,7);
INSERT INTO content_genres VALUES (102,4),(102,3),(102,5),(102,8);
INSERT INTO content_genres VALUES (103,4),(103,3),(103,5),(103,8);
INSERT INTO content_genres VALUES (104,3),(104,5);
INSERT INTO content_genres VALUES (105,7),(105,10),(105,18);
INSERT INTO content_genres VALUES (106,11),(106,17),(106,7);
INSERT INTO content_genres VALUES (107,1),(107,3),(107,16),(107,9);
INSERT INTO content_genres VALUES (108,1),(108,3),(108,16),(108,9);
INSERT INTO content_genres VALUES (109,1),(109,3),(109,16),(109,9);
INSERT INTO content_genres VALUES (110,1),(110,3),(110,16);
INSERT INTO content_genres VALUES (111,4),(111,3),(111,5),(111,8);
INSERT INTO content_genres VALUES (112,4),(112,1),(112,3),(112,16);
INSERT INTO content_genres VALUES (113,4),(113,1),(113,3),(113,16);
INSERT INTO content_genres VALUES (114,16),(114,7),(114,3);
INSERT INTO content_genres VALUES (115,16),(115,1),(115,17);
INSERT INTO content_genres VALUES (116,1),(116,6),(116,7);
INSERT INTO content_genres VALUES (117,16),(117,3),(117,7);
INSERT INTO content_genres VALUES (118,16),(118,3),(118,7);
INSERT INTO content_genres VALUES (119,7),(119,10),(119,17);
INSERT INTO content_genres VALUES (120,5),(120,9),(120,3);
INSERT INTO content_genres VALUES (121,7),(121,15);
INSERT INTO content_genres VALUES (122,5),(122,9),(122,15);

DELIMITER $$
CREATE PROCEDURE gen_eps_novid(IN sid INT, IN cnt INT, IN dur VARCHAR(20))
BEGIN
  DECLARE i INT DEFAULT 1;
  WHILE i <= cnt DO
    INSERT INTO episodes(season_id, episode_number, title, duration)
      VALUES(sid, i, CONCAT('Episode ', i), dur);
    SET i = i + 1;
  END WHILE;
END$$
DELIMITER ;

-- Amphibia
INSERT INTO seasons(id,content_id,season_number) VALUES(1,1,1),(2,1,2),(3,1,3);
CALL gen_eps_novid(1,20,'23 min'); CALL gen_eps_novid(2,22,'23 min'); CALL gen_eps_novid(3,18,'23 min');

-- Gravity Falls
INSERT INTO seasons(id,content_id,season_number) VALUES(4,2,1),(5,2,2);
CALL gen_eps_novid(4,20,'22 min'); CALL gen_eps_novid(5,20,'22 min');

-- The Neighbourhood
INSERT INTO seasons(id,content_id,season_number) VALUES(6,3,1),(7,3,2);
CALL gen_eps_novid(6,22,'22 min'); CALL gen_eps_novid(7,22,'22 min');

-- Grey's Anatomy
INSERT INTO seasons(id,content_id,season_number) VALUES(8,4,1),(9,4,2);
CALL gen_eps_novid(8,9,'43 min'); CALL gen_eps_novid(9,27,'43 min');

-- Helluva Boss
INSERT INTO seasons(id,content_id,season_number) VALUES(10,5,1),(11,5,2);
INSERT INTO episodes(season_id,episode_number,title,duration,video_url) VALUES
(10,1,'Murder Family','25 min','https://www.youtube.com/embed/el_PChGfJN8'),
(10,2,'Loo Loo Land','25 min','https://www.youtube.com/embed/kpnwRg268FQ'),
(10,3,'Spring Broken','25 min','https://www.youtube.com/embed/RghsgkZKedg'),
(10,4,'C.H.E.R.U.B','25 min','https://www.youtube.com/embed/1ZFseYPmkAk'),
(10,5,'The Harvest Moon Festival','25 min','https://www.youtube.com/embed/h2ZmVAdezF8'),
(10,6,'Truth Seekers','25 min','https://www.youtube.com/embed/yXErLiSbxXQ'),
(10,7,'OZZIE''S (Uncut)','25 min','https://www.youtube.com/embed/8zyGQquL8VM'),
(10,8,'Queen Bee','25 min','https://www.youtube.com/embed/D-2799Y07Zc'),
(11,1,'The Circus','25 min','https://www.youtube.com/embed/_spuxXnul0U'),
(11,2,'SEEING STARS','25 min','https://www.youtube.com/embed/4J0xFUyz1nw'),
(11,3,'Exes and oohs','25 min','https://www.youtube.com/embed/j1BfO7VlIw4'),
(11,4,'Western Energy','25 min','https://www.youtube.com/embed/KJy7T24rhg0'),
(11,5,'Unhappy Campers','25 min','https://www.youtube.com/embed/lYu1ysDULwA?'),
(11,6,'Mille Folia','25 min','https://www.youtube.com/embed/y1sF6ZeASU0'),
(11,7,'Mammon''s Magnificent Musical Mid-Season Special','25 min','https://www.youtube.com/embed/rRymSi8SmqA'),
(11,8,'Queen Bee','25 min','https://www.youtube.com/embed/Fj9YRsV1pEw');

-- Hazbin Hotel
INSERT INTO seasons(id,content_id,season_number) VALUES(12,6,1);
CALL gen_eps_novid(12,8,'30 min');

-- The Amazing Digital Circus
INSERT INTO seasons(id,content_id,season_number) VALUES(13,7,1);
INSERT INTO episodes(season_id,episode_number,title,duration,video_url) VALUES
(13,1,'Pilot','20 min','https://www.youtube.com/embed/iuaRQ5NQFq8'),
(13,2,'Candy Carrier Chaos!','20 min','https://www.youtube.com/embed/HuqyXCBiThQ'),
(13,3,'The Breakfast Bunch','20 min','https://www.youtube.com/embed/Cv_8tHgZrCM'),
(13,4,'A Cyberfun Town for Cyberfun People','20 min','https://www.youtube.com/embed/iFTHFGpbHjU');

-- Murder Drones
INSERT INTO seasons(id,content_id,season_number) VALUES(14,8,1);
INSERT INTO episodes(season_id,episode_number,title,duration,video_url) VALUES
(14,1,'Pilot','22 min','https://www.youtube.com/embed/mImFz8mkaHo'),
(14,2,'Heartbeat','22 min','https://www.youtube.com/embed/7z8DO1KhPFo'),
(14,3,'The Promening','22 min','https://www.youtube.com/embed/djsJqNAGMuY'),
(14,4,'Cabin Fever','22 min','https://www.youtube.com/embed/63bUBEIhpNk'),
(14,5,'Home','22 min','https://www.youtube.com/embed/rk0HBqSqpgg'),
(14,6,'Dead End','22 min','https://www.youtube.com/embed/U7i6fi3z9Nk'),
(14,7,'Mass Destruction','22 min','https://www.youtube.com/embed/EOqw86OGIB0'),
(14,8,'The Absolute Robot','22 min','https://www.youtube.com/embed/caR9ouipm8o');

-- Avatar: TLA
INSERT INTO seasons(id,content_id,season_number) VALUES(15,9,1),(16,9,2),(17,9,3);
CALL gen_eps_novid(15,20,'23 min'); CALL gen_eps_novid(16,20,'23 min'); CALL gen_eps_novid(17,21,'23 min');

-- Ghosts
INSERT INTO seasons(id,content_id,season_number) VALUES(18,10,1),(19,10,2);
CALL gen_eps_novid(18,18,'22 min'); CALL gen_eps_novid(19,22,'22 min');

-- The Rookie
INSERT INTO seasons(id,content_id,season_number) VALUES(20,11,1),(21,11,2),(22,11,3);
CALL gen_eps_novid(20,20,'43 min'); CALL gen_eps_novid(21,20,'43 min'); CALL gen_eps_novid(22,14,'43 min');

-- Arcane
INSERT INTO seasons(id,content_id,season_number) VALUES(23,12,1),(24,12,2);
CALL gen_eps_novid(23,9,'40 min'); CALL gen_eps_novid(24,9,'40 min');

-- The Last of Us
INSERT INTO seasons(id,content_id,season_number) VALUES(25,13,1),(26,13,2);
CALL gen_eps_novid(25,9,'55 min'); CALL gen_eps_novid(26,7,'55 min');

-- The Walking Dead
INSERT INTO seasons(id,content_id,season_number) VALUES 
(27,14,1),(28,14,2),(29,14,3),(30,14,4),(31,14,5),(32,14,6),(33,14,7),(34,14,8),(35,14,9),(36,14,10),(37,14,11);
CALL gen_eps_novid(27,6,'45 min'); CALL gen_eps_novid(28,13,'45 min'); CALL gen_eps_novid(29,16,'45 min'); 
CALL gen_eps_novid(30,16,'45 min'); CALL gen_eps_novid(31,16,'45 min'); CALL gen_eps_novid(32,16,'45 min'); 
CALL gen_eps_novid(33,16,'45 min'); CALL gen_eps_novid(34,16,'45 min'); CALL gen_eps_novid(35,16,'45 min'); 
CALL gen_eps_novid(36,22,'45 min'); CALL gen_eps_novid(37,24,'45 min');

-- Alice in Borderland
INSERT INTO seasons(id,content_id,season_number) VALUES(38,15,1),(39,15,2);
CALL gen_eps_novid(38,8,'50 min'); CALL gen_eps_novid(39,8,'50 min');

-- Breaking Bad
INSERT INTO seasons(id,content_id,season_number) VALUES(40,16,1),(41,16,2),(42,16,3),(43,16,4),(44,16,5);
CALL gen_eps_novid(40,7,'47 min'); CALL gen_eps_novid(41,13,'47 min'); CALL gen_eps_novid(42,13,'47 min'); CALL gen_eps_novid(43,13,'47 min'); CALL gen_eps_novid(44,16,'47 min');

-- Stranger Things
INSERT INTO seasons(id,content_id,season_number) VALUES(45,17,1),(46,17,2),(47,17,3),(48,17,4);
CALL gen_eps_novid(45,8,'51 min'); CALL gen_eps_novid(46,9,'55 min'); CALL gen_eps_novid(47,8,'52 min'); CALL gen_eps_novid(48,9,'77 min');

-- Wednesday
INSERT INTO seasons(id,content_id,season_number) VALUES(49,18,1);
CALL gen_eps_novid(49,8,'48 min');

-- One Piece
INSERT INTO seasons(id,content_id,season_number) VALUES(50,19,1),(51,19,2),(52,19,3),(53,19,4);
CALL gen_eps_novid(50,61,'24 min'); CALL gen_eps_novid(51,16,'24 min'); CALL gen_eps_novid(52,14,'24 min'); CALL gen_eps_novid(53,39,'24 min');

-- Demon Slayer
INSERT INTO seasons(id,content_id,season_number) VALUES(54,20,1),(55,20,2),(56,20,3);
CALL gen_eps_novid(54,26,'24 min'); CALL gen_eps_novid(55,18,'24 min'); CALL gen_eps_novid(56,11,'24 min');

-- Jujutsu Kaisen
INSERT INTO seasons(id,content_id,season_number) VALUES(57,21,1),(58,21,2);
CALL gen_eps_novid(57,24,'24 min'); CALL gen_eps_novid(58,23,'24 min');

-- The Bear
INSERT INTO seasons(id,content_id,season_number) VALUES(59,22,1),(60,22,2);
CALL gen_eps_novid(59,8,'30 min'); CALL gen_eps_novid(60,10,'35 min');

-- Succession
INSERT INTO seasons(id,content_id,season_number) VALUES(61,23,1),(62,23,2),(63,23,3),(64,23,4);
CALL gen_eps_novid(61,10,'60 min'); CALL gen_eps_novid(62,10,'60 min'); CALL gen_eps_novid(63,10,'60 min'); CALL gen_eps_novid(64,10,'60 min');

DROP PROCEDURE IF EXISTS gen_eps_novid;

SELECT 'HopFlix seed data loaded!' AS status;
