var currentItem = null, currentSeason = 1, currentEp = 1, ctrlTimer = null;

document.addEventListener('DOMContentLoaded', async function() {
  await checkSession();
  buildNavbar('');
  buildFooter();
  var id = new URLSearchParams(window.location.search).get('id');
  if (!id) { showErr('No content ID in URL.'); return; }
  currentItem = await getById(parseInt(id));
  if (!currentItem || currentItem.error) { showErr('Content not found.'); return; }
  document.title = 'HopFlix — ' + currentItem.title;
  incrementView(currentItem.id);
  initPlayer();
  loadInfo();
  loadSimilar();
  if (currentItem.type === 'series') { loadSeasonSel(); loadEps(1, 1); }
  if (isLoggedIn()) addToHistory(currentItem.id, 0);
});

function initPlayer() {
  var item = currentItem;
  if (item.type === 'movie') {
    if (item.videoSrc) {
      showYouTubePlayer(item.videoSrc);
    } else {
      showNoVideo();
    }
  }
}

function showNoVideo() {
  var pw = document.getElementById('player-wrap');
  hideNativePlayer();
  var existing = document.getElementById('no-video-msg');
  if (!existing) {
    var msg = document.createElement('div');
    msg.id = 'no-video-msg';
    msg.style.cssText = 'position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;color:rgba(255,255,255,0.5);font-size:14px;gap:8px;';
    msg.innerHTML = '<i class="fa-solid fa-film" style="font-size:36px;opacity:0.4;"></i><span>No trailer available</span>';
    pw.appendChild(msg);
  }
}


function hideNativePlayer() {
  var v = document.getElementById('main-player');
  if (v) { v.pause(); v.src = ''; v.style.display = 'none'; }
  var ctrl = document.getElementById('player-controls');
  var clk  = document.getElementById('player-click');
  if (ctrl) ctrl.style.display = 'none';
  if (clk)  clk.style.display  = 'none';
}

function showYouTubePlayer(embedUrl) {
  hideNativePlayer();
  var pw = document.getElementById('player-wrap');


  var noVid = document.getElementById('no-video-msg');
  if (noVid) noVid.remove();

  var yi = document.getElementById('yt-ep-iframe');
  if (!yi) {
    yi = document.createElement('iframe');
    yi.id = 'yt-ep-iframe';
    yi.frameBorder = '0';
    yi.allow = 'autoplay; encrypted-media; fullscreen';
    yi.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;background:#000;border:none;';
    pw.appendChild(yi);
  }
  yi.style.display = '';
  var sep = embedUrl.includes('?') ? '&' : '?';
  yi.src = embedUrl + sep + 'autoplay=1';
}

function playEp(sn, ep) {
  currentSeason = sn; currentEp = ep; loadEps(sn, ep);
  var season  = currentItem.seasons.find(function(s) { return s.number === sn; });
  var episode = season ? season.episodes.find(function(e) { return e.ep === ep; }) : null;
  if (episode && episode.videoSrc) {
    showYouTubePlayer(episode.videoSrc);
  } else {
    showNoVideo();
  }
  document.getElementById('player-wrap').scrollIntoView({ behavior: 'smooth' });
}

function loadSeasonSel() {
  document.getElementById('eps-section').style.display = 'block';
  var sel = document.getElementById('season-sel');
  sel.innerHTML = currentItem.seasons.map(function(s) {
    return '<option value="' + s.number + '">Season ' + s.number + '</option>';
  }).join('');
}
function loadSeason(n) { currentSeason = parseInt(n); loadEps(currentSeason, 1); }
function loadEps(sn, activeEp) {
  var season = currentItem.seasons.find(function(s) { return s.number === sn; });
  if (!season) return;
  document.getElementById('eps-list').innerHTML = season.episodes.map(function(ep) {
    return '<div class="ep-item ' + (ep.ep === activeEp ? 'active' : '') + '" onclick="playEp(' + sn + ',' + ep.ep + ')">' +
      '<span class="ep-num">E' + ep.ep + '</span>' +
      '<div class="ep-info"><strong>' + ep.title + '</strong>' +
      '<small>Season ' + sn + ' · Episode ' + ep.ep + ' · ' + ep.duration + '</small></div>' +
      '<button class="ep-play"><i class="fa-solid fa-play" style="margin-left:1px;font-size:10px;"></i></button>' +
    '</div>';
  }).join('');
}

function loadInfo() {
  var item = currentItem;
  document.getElementById('info-poster').src = item.cover;
  document.getElementById('info-poster').alt = item.title;
  document.getElementById('info-title').textContent = item.title;
  var sc = item.seasons ? item.seasons.length : 0;
  var te = item.seasons ? item.seasons.reduce(function(t, s) { return t + s.episodes.length; }, 0) : 0;
  document.getElementById('info-meta').innerHTML =
    '<span class="info-badge">' + (item.type === 'movie' ? 'Movie' : 'Series') + '</span>' +
    '<span>' + item.year + '</span>' +
    '<span class="rating-big">&#11088; ' + item.rating + '/10</span>' +
    (item.type === 'movie'
      ? '<span class="info-badge"><i class="fa-solid fa-clock"></i> ' + (item.duration || '') + '</span>'
      : '<span class="info-badge">' + sc + ' Season' + (sc > 1 ? 's' : '') + '</span><span class="info-badge">' + te + ' Episodes</span>');
  document.getElementById('info-desc').textContent = item.description;
  document.getElementById('info-tags').innerHTML = item.genres.map(function(g) {
    return '<a href="/HopFlix/pages/genre/genre.html?genre=' + encodeURIComponent(g) + '" class="info-tag">' + g + '</a>';
  }).join('');
  updateFavBtn();
}

function updateFavBtn() {
  var btn = document.getElementById('fav-btn');
  if (!btn || !currentItem) return;
  var fav = isFavourite(currentItem.id);
  btn.innerHTML = fav ? '<i class="fa-solid fa-heart"></i> In Favourites' : '<i class="fa-regular fa-heart"></i> Add to Favourites';
  btn.classList.toggle('active', fav);
}
async function handleFav() {
  if (!isLoggedIn()) { openAuthModal('login'); return; }
  await toggleFavourite(currentItem.id);
  updateFavBtn();
}


async function loadSimilar() {
  var grid    = document.getElementById('similar-grid');
  var similar = await getSimilar(currentItem.id, 6);
  if (!similar || !similar.length) { grid.parentElement.style.display = 'none'; return; }
  grid.innerHTML = similar.map(buildCard).join('');
}

function playTrailer() {
  if (!currentItem || !currentItem.trailer || currentItem.trailer.includes('placeholder')) return;
  var url = currentItem.trailer;
  var embedUrl = url
    .replace(/https?:\/\/(www\.)?youtube\.com\/watch\?v=([^&]+).*/, 'https://www.youtube.com/embed/$2')
    .replace(/https?:\/\/youtu\.be\/([^?]+).*/, 'https://www.youtube.com/embed/$1');
  document.getElementById('trailer-iframe').src = embedUrl + (embedUrl.includes('?') ? '&autoplay=1' : '?autoplay=1');
  document.getElementById('trailer-modal').classList.add('open');
}
function closeTrailer() {
  document.getElementById('trailer-iframe').src = '';
  document.getElementById('trailer-modal').classList.remove('open');
}

function fmt(s) {
  if (!s || isNaN(s)) return '0:00';
  var h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = Math.floor(s % 60);
  return h > 0 ? h + ':' + String(m).padStart(2, '0') + ':' + String(sec).padStart(2, '0') : m + ':' + String(sec).padStart(2, '0');
}
function showErr(msg) {
  document.querySelector('.player-section').innerHTML =
    '<div style="text-align:center;padding:80px 24px;color:var(--text-muted);margin-top:var(--nav-height);">' +
    '<i class="fa-solid fa-circle-exclamation" style="font-size:48px;margin-bottom:14px;display:block;"></i>' +
    '<h2 style="color:var(--white);margin-bottom:8px;">Oops!</h2><p>' + msg + '</p>' +
    '<a href="/HopFlix/pages/home/home.html" style="display:inline-block;margin-top:16px;background:var(--purple);color:white;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700;">Back to Home</a>' +
    '</div>';
}
